/*
 * Copyright (C) 2015 MediaTek Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 */

#include <linux/module.h>

#if 0
/*use ccf instead of these two functions, will delete this file after all owner already use CCF*/
int enable_clock(int id, char *name)
{
	return 0;
}
EXPORT_SYMBOL(enable_clock);


int disable_clock(int id, char *name)
{
	return 0;
}
EXPORT_SYMBOL(disable_clock);
#endif
