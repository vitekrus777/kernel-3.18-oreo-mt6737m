/*
* Copyright (C) 2016 MediaTek Inc.
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License version 2 as
* published by the Free Software Foundation.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
* See http://www.gnu.org/licenses/gpl-2.0.html for more details.
*/
#include <linux/videodev2.h>
#include <linux/i2c.h>
#include <linux/platform_device.h>
#include <linux/delay.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/fs.h>
#include <asm/atomic.h>

#include "kd_camera_hw.h"

#include "kd_imgsensor.h"
#include "kd_imgsensor_define.h"
#include "kd_camera_feature.h"

/******************************************************************************
 * Debug configuration
******************************************************************************/
#define PFX "[kd_camera_hw]"
#define PK_DBG_NONE(fmt, arg...)    do {} while (0)
#define PK_DBG_FUNC(fmt, args...)    pr_debug(PFX  fmt, ##args)

//#define DEBUG_CAMERA_HW_K
#ifdef DEBUG_CAMERA_HW_K
#define PK_DBG PK_DBG_FUNC
#define PK_ERR(fmt, arg...) pr_err(fmt, ##arg)
#define PK_XLOG_INFO(fmt, args...)  pr_debug(PFX  fmt, ##args)

#else
#define PK_DBG(a, ...)
#define PK_ERR(a, ...)
#define PK_XLOG_INFO(fmt, args...)
#endif

#define OPIUM_CAM_SUPPORT

PowerUp PowerOnList={
    {
	#if defined(IMX219_MIPI_RAW)
	    {SENSOR_DRVNAME_IMX219_MIPI_RAW,
		   {
				{SensorId, MAIN_SENSOR, 0},
				{SensorMCLK, Mclk1, 0},
				{RST, Vol_Low, 0},
				{PDN, Vol_Low, 0},
				{DVDD, Vol_1200, 10},
				{AVDD, Vol_2800, 10},
				{DOVDD, Vol_1800, 10},
				{AFVDD, Vol_2800, 10},
				{RST, Vol_High, 10},
				{PDN, Vol_High, 10},
		   },
	    },
	#endif
	#if defined(HI843B_MIPI_RAW)
	    {SENSOR_DRVNAME_HI843B_MIPI_RAW,
		   {
				{SensorId, MAIN_SENSOR, 0},
				{SensorMCLK, Mclk1, 0},
				{RST, Vol_Low, 0},
				{PDN, Vol_Low, 0},
				{DVDD, Vol_1200, 10},
				{AVDD, Vol_2800, 10},
				{DOVDD, Vol_1800, 10},
				{AFVDD, Vol_2800, 10},
				{RST, Vol_High, 10},
				{PDN, Vol_High, 10},
		   },
	    },
	#endif
    #if defined(GC2365_MIPI_RAW)
		{SENSOR_DRVNAME_GC2365_MIPI_RAW,
            {
				{SensorId, SUB_SENSOR, 0},
				{SensorMCLK, Mclk1, 0},
				{RST,	Vol_Low,  0},
				{PDN,	Vol_High,  0},
				{AVDD,	Vol_2800, 10},
				{DOVDD, Vol_1800, 10},
				{DVDD,	Vol_1500, 10},
				{RST,	Vol_High, 10},
				{PDN,	Vol_Low, 10},
				{PDN,	Vol_High, 20},
				{PDN,	Vol_Low, 10},
            },
        },
	#endif

        {NULL,},
    }
};

static u32 pinSetIdx = 0;//default main sensor
/* GPIO Pin control*/
struct platform_device *cam_plt_dev = NULL;
struct pinctrl *camctrl = NULL;
struct pinctrl_state *cam0_pnd_h = NULL;
struct pinctrl_state *cam0_pnd_l = NULL;
struct pinctrl_state *cam0_rst_h = NULL;
struct pinctrl_state *cam0_rst_l = NULL;
struct pinctrl_state *cam1_pnd_h = NULL;
struct pinctrl_state *cam1_pnd_l = NULL;
struct pinctrl_state *cam1_rst_h = NULL;
struct pinctrl_state *cam1_rst_l = NULL;
struct pinctrl_state *cam_ldo0_h = NULL; //CAMA
struct pinctrl_state *cam_ldo0_l = NULL; //CAMA
struct pinctrl_state *cam_ldo1_h = NULL; //CAMD
struct pinctrl_state *cam_ldo1_l = NULL; //CAMD

int mtkcam_gpio_init(struct platform_device *pdev)
{
	int ret = 0;

	camctrl = devm_pinctrl_get(&pdev->dev);
	if (IS_ERR(camctrl)) {
		dev_err(&pdev->dev, "Cannot find camera pinctrl!");
		ret = PTR_ERR(camctrl);
	}
	/*Cam0 Power/Rst Ping initialization */
	cam0_pnd_h = pinctrl_lookup_state(camctrl, "cam0_pnd1");
	if (IS_ERR(cam0_pnd_h)) {
		ret = PTR_ERR(cam0_pnd_h);
		pr_debug("%s : pinctrl err, cam0_pnd_h\n", __func__);
	}

	cam0_pnd_l = pinctrl_lookup_state(camctrl, "cam0_pnd0");
	if (IS_ERR(cam0_pnd_l)) {
		ret = PTR_ERR(cam0_pnd_l);
		pr_debug("%s : pinctrl err, cam0_pnd_l\n", __func__);
	}


	cam0_rst_h = pinctrl_lookup_state(camctrl, "cam0_rst1");
	if (IS_ERR(cam0_rst_h)) {
		ret = PTR_ERR(cam0_rst_h);
		pr_debug("%s : pinctrl err, cam0_rst_h\n", __func__);
	}

	cam0_rst_l = pinctrl_lookup_state(camctrl, "cam0_rst0");
	if (IS_ERR(cam0_rst_l)) {
		ret = PTR_ERR(cam0_rst_l);
		pr_debug("%s : pinctrl err, cam0_rst_l\n", __func__);
	}

	/*Cam1 Power/Rst Ping initialization */
	cam1_pnd_h = pinctrl_lookup_state(camctrl, "cam1_pnd1");
	if (IS_ERR(cam1_pnd_h)) {
		ret = PTR_ERR(cam1_pnd_h);
		pr_debug("%s : pinctrl err, cam1_pnd_h\n", __func__);
	}

	cam1_pnd_l = pinctrl_lookup_state(camctrl, "cam1_pnd0");
	if (IS_ERR(cam1_pnd_l)) {
		ret = PTR_ERR(cam1_pnd_l);
		pr_debug("%s : pinctrl err, cam1_pnd_l\n", __func__);
	}


	cam1_rst_h = pinctrl_lookup_state(camctrl, "cam1_rst1");
	if (IS_ERR(cam1_rst_h)) {
		ret = PTR_ERR(cam1_rst_h);
		pr_debug("%s : pinctrl err, cam1_rst_h\n", __func__);
	}


	cam1_rst_l = pinctrl_lookup_state(camctrl, "cam1_rst0");
	if (IS_ERR(cam1_rst_l)) {
		ret = PTR_ERR(cam1_rst_l);
		pr_debug("%s : pinctrl err, cam1_rst_l\n", __func__);
	}
	/*externel LDO enable */
#ifdef GPIO_VCAMA_LDO
	cam_ldo0_h = pinctrl_lookup_state(camctrl, "cam_ldo0_1");
	if (IS_ERR(cam_ldo0_h)) {
		ret = PTR_ERR(cam_ldo0_h);
		pr_debug("%s : pinctrl err, cam_ldo0_h\n", __func__);
	}


	cam_ldo0_l = pinctrl_lookup_state(camctrl, "cam_ldo0_0");
	if (IS_ERR(cam_ldo0_l)) {
		ret = PTR_ERR(cam_ldo0_l);
		pr_debug("%s : pinctrl err, cam_ldo0_l\n", __func__);
	}
#endif
#ifdef GPIO_VCAMD_LDO
	cam_ldo1_h = pinctrl_lookup_state(camctrl, "cam_ldo1_1");
	if (IS_ERR(cam_ldo1_h)) {
		ret = PTR_ERR(cam_ldo1_h);
		PK_ERR("%s : pinctrl err, cam_ldo1_h\n", __func__);
	}
	cam_ldo1_l = pinctrl_lookup_state(camctrl, "cam_ldo1_0");
	if (IS_ERR(cam_ldo1_l)) {
		ret = PTR_ERR(cam_ldo1_l);
		PK_ERR("%s : pinctrl err, cam_ldo1_l\n", __func__);
	}
#endif
	return ret;
}
EXPORT_SYMBOL(mtkcam_gpio_init);

int mtkcam_gpio_set(int PinIdx, int PwrType, int Val)
{
	int ret = 0;

	switch (PwrType) {
	case CAMRST:
		if (PinIdx == 0) {
			if (Val == 0)
				pinctrl_select_state(camctrl, cam0_rst_l);
			else
				pinctrl_select_state(camctrl, cam0_rst_h);
		} else {
			if (Val == 0)
				pinctrl_select_state(camctrl, cam1_rst_l);
			else
				pinctrl_select_state(camctrl, cam1_rst_h);
		}
		break;
	case CAMPDN:
		if (PinIdx == 0) {
			if (Val == 0)
				pinctrl_select_state(camctrl, cam0_pnd_l);
			else
				pinctrl_select_state(camctrl, cam0_pnd_h);
		} else {
			if (Val == 0)
				pinctrl_select_state(camctrl, cam1_pnd_l);
			else
				pinctrl_select_state(camctrl, cam1_pnd_h);
		}

		break;
#ifdef GPIO_VCAMA_LDO
	case CAMALDO:
		if (Val == 0)
			pinctrl_select_state(camctrl, cam_ldo0_l);
		else
			pinctrl_select_state(camctrl, cam_ldo0_h);
		break;
#endif
#ifdef GPIO_VCAMD_LDO
	case CAMDLDO:
		if (Val == 0)
			pinctrl_select_state(camctrl, cam_ldo1_l);
		else
			pinctrl_select_state(camctrl, cam_ldo1_h);
		break;
#endif
	default:
		PK_DBG("PwrType(%d) is invalid !!\n", PwrType);
		break;
	};

	PK_DBG("PinIdx(%d) PwrType(%d) val(%d)\n", PinIdx, PwrType, Val);

	return ret;
}




int cntVCAMD = 0;
int cntVCAMA = 0;
int cntVCAMIO = 0;
int cntVCAMAF = 0;
int cntVCAMD_SUB = 0;

static DEFINE_SPINLOCK(kdsensor_pw_cnt_lock);


bool _hwPowerOnCnt(KD_REGULATOR_TYPE_T powerId, int powerVolt, char *mode_name)
{

	if (_hwPowerOn(powerId, powerVolt)) {
		spin_lock(&kdsensor_pw_cnt_lock);
		if (powerId == VCAMD)
			cntVCAMD += 1;
		else if (powerId == VCAMA)
			cntVCAMA += 1;
		else if (powerId == VCAMIO)
			cntVCAMIO += 1;
		else if (powerId == VCAMAF)
			cntVCAMAF += 1;
		else if (powerId == SUB_VCAMD)
			cntVCAMD_SUB += 1;
		spin_unlock(&kdsensor_pw_cnt_lock);
		return true;
	}
	return false;
}

bool _hwPowerDownCnt(KD_REGULATOR_TYPE_T powerId, char *mode_name)
{

	if (_hwPowerDown(powerId)) {
		spin_lock(&kdsensor_pw_cnt_lock);
		if (powerId == VCAMD)
			cntVCAMD -= 1;
		else if (powerId == VCAMA)
			cntVCAMA -= 1;
		else if (powerId == VCAMIO)
			cntVCAMIO -= 1;
		else if (powerId == VCAMAF)
			cntVCAMAF -= 1;
		else if (powerId == SUB_VCAMD)
			cntVCAMD_SUB -= 1;
		spin_unlock(&kdsensor_pw_cnt_lock);
		return true;
	}
	return false;
}

void checkPowerBeforClose(char *mode_name)
{

	int i = 0;

	PK_DBG
	    ("[checkPowerBeforClose]cntVCAMD:%d, cntVCAMA:%d,cntVCAMIO:%d, cntVCAMAF:%d, cntVCAMD_SUB:%d,\n",
	     cntVCAMD, cntVCAMA, cntVCAMIO, cntVCAMAF, cntVCAMD_SUB);


	for (i = 0; i < cntVCAMD; i++)
		_hwPowerDown(VCAMD);
	for (i = 0; i < cntVCAMA; i++)
		_hwPowerDown(VCAMA);
	for (i = 0; i < cntVCAMIO; i++)
		_hwPowerDown(VCAMIO);
	for (i = 0; i < cntVCAMAF; i++)
		_hwPowerDown(VCAMAF);
	for (i = 0; i < cntVCAMD_SUB; i++)
		_hwPowerDown(SUB_VCAMD);

	cntVCAMD = 0;
	cntVCAMA = 0;
	cntVCAMIO = 0;
	cntVCAMAF = 0;
	cntVCAMD_SUB = 0;

}
EXPORT_SYMBOL(checkPowerBeforClose);

BOOL hwpoweron(PowerInformation pwInfo, char* mode_name)
{
    if(pwInfo.PowerType == AVDD)
    {
    #ifdef GPIO_VCAMA_LDO
		mtkcam_gpio_set(pinSetIdx, CAMALDO, 1);
	#endif
		if(TRUE != _hwPowerOnCnt(VCAMA,pwInfo.Voltage,mode_name))
		{
			PK_ERR("[CAMERA AVDD] Fail to enable power\n");
			return FALSE;
		}
    }
    else if(pwInfo.PowerType == DVDD)
    {
    #ifdef GPIO_VCAMD_LDO
		mtkcam_gpio_set(pinSetIdx, CAMDLDO, 1);
	#endif
		if(TRUE != _hwPowerOnCnt(VCAMD,pwInfo.Voltage,mode_name))
		{
			PK_ERR("[CAMERA DVDD] Fail to enable power\n");
			return FALSE;
		}
    }
    else if(pwInfo.PowerType == DOVDD)
    {
		if(TRUE != _hwPowerOnCnt(VCAMIO,pwInfo.Voltage,mode_name))
		{
			PK_ERR("[CAMERA DOVDD] Fail to enable power\n");
			return FALSE;
		}
    }
    else if(pwInfo.PowerType == AFVDD)
    {
		if(TRUE != _hwPowerOnCnt(VCAMAF,pwInfo.Voltage,mode_name))
		{
			PK_ERR("[CAMERA AFVDD] Fail to enable power\n");
			return FALSE;
		}
    }
    else if(pwInfo.PowerType==PDN)
    {
        if(pwInfo.Voltage == Vol_High)
        {
			mtkcam_gpio_set(pinSetIdx, CAMPDN, 1);
        }
        else
        {
			mtkcam_gpio_set(pinSetIdx, CAMPDN, 0);
        }
    }
    else if(pwInfo.PowerType==RST)
    {
        if(pwInfo.Voltage == Vol_High)
        {
			mtkcam_gpio_set(pinSetIdx, CAMRST, 1);
        }
        else
        {
			mtkcam_gpio_set(pinSetIdx, CAMRST, 0);
        }
    }
    else if(pwInfo.PowerType==SensorMCLK)
    {
        if(pwInfo.Voltage == Mclk1)
        {
            PK_DBG("Sensor MCLK1 On");
            ISP_MCLK1_EN(TRUE);
        }
        else if(pwInfo.Voltage == Mclk2)
        {
            PK_DBG("Sensor MCLK2 On");
            //ISP_MCLK2_EN(TRUE);
        }
    }
    else
	{
	}

    if(pwInfo.Delay>0)
        mdelay(pwInfo.Delay);

    return TRUE;
}

BOOL hwpowerdown(PowerInformation pwInfo, char* mode_name)
{
    if(pwInfo.PowerType == AVDD)
    {
    #ifdef GPIO_VCAMA_LDO
		mtkcam_gpio_set(pinSetIdx, CAMALDO, 0);
	#endif
		if(TRUE != _hwPowerDownCnt(VCAMA,mode_name))
		{
			PK_ERR("[CAMERA AVDD] Fail to disable power\n");
			return FALSE;
		}
    }
    else if(pwInfo.PowerType == DVDD)
    {
    #ifdef GPIO_VCAMD_LDO
		mtkcam_gpio_set(pinSetIdx, CAMDLDO, 0);
	#endif
		if(TRUE != _hwPowerDownCnt(VCAMD,mode_name))
		{
			PK_ERR("[CAMERA DVDD] Fail to disable power\n");
			return FALSE;
		}
    }
    else if(pwInfo.PowerType == DOVDD)
    {
		if(TRUE != _hwPowerDownCnt(VCAMIO,mode_name))
		{
			PK_ERR("[CAMERA DOVDD] Fail to disable power\n");
			return FALSE;
		}
    }
    else if(pwInfo.PowerType == AFVDD)
    {
		if(TRUE != _hwPowerDownCnt(VCAMAF,mode_name))
		{
			PK_ERR("[CAMERA AFVDD] Fail to disable power\n");
			return FALSE;
		}
    }
    else if(pwInfo.PowerType==PDN)
    {
        if(pwInfo.Voltage == Vol_High)
        {
			mtkcam_gpio_set(pinSetIdx, CAMPDN, 1);
        }
        else
        {
			mtkcam_gpio_set(pinSetIdx, CAMPDN, 0);
        }
    }
    else if(pwInfo.PowerType==RST)
    {
        if(pwInfo.Voltage == Vol_High)
        {
			mtkcam_gpio_set(pinSetIdx, CAMRST, 1);
        }
        else
        {
			mtkcam_gpio_set(pinSetIdx, CAMRST, 0);
        }
    }
    else if(pwInfo.PowerType==SensorMCLK)
    {
        if(pwInfo.Voltage == Mclk1)
        {
            PK_DBG("Sensor MCLK1 Off");
			ISP_MCLK1_EN(FALSE);
        }
        else if(pwInfo.Voltage == Mclk2)
        {
			PK_DBG("Sensor MCLK2 Off");
            //ISP_MCLK2_EN(FALSE);
        }
    }
    else
	{
	}

    return TRUE;
}

int kdCISModulePowerOn(CAMERA_DUAL_CAMERA_SENSOR_ENUM SensorIdx, char *currSensorName, BOOL On, char* mode_name)
{
    int pwListIdx,pwIdx;
    BOOL sensorInPowerList = KAL_FALSE;

    if (DUAL_CAMERA_MAIN_SENSOR == SensorIdx){
        pinSetIdx = 0;
    }
    else if (DUAL_CAMERA_SUB_SENSOR == SensorIdx) {
        pinSetIdx = 1;
    }
    else if (DUAL_CAMERA_MAIN_2_SENSOR == SensorIdx) {
        pinSetIdx = 2;
    }

    //power ON
    if (On) {
        PK_ERR("kdCISModulePowerOn :currSensorName=%s,pinSetIdx=%d\n",currSensorName,pinSetIdx);

		for(pwListIdx=0; pwListIdx<16; pwListIdx++)
        {
            if(currSensorName && (PowerOnList.PowerSeq[pwListIdx].SensorName!=NULL) && (0 == strcmp(PowerOnList.PowerSeq[pwListIdx].SensorName,currSensorName)))
            {
                PK_DBG("kdCISModulePowerOn get in---sensorIdx:%d\n",SensorIdx);

                sensorInPowerList = KAL_TRUE;

                for(pwIdx=1; pwIdx<15; pwIdx++)
                {
                    if(PowerOnList.PowerSeq[pwListIdx].PowerInfo[pwIdx].PowerType != VDD_None)
                    {
					#ifdef OPIUM_CAM_SUPPORT
                        if((PowerOnList.PowerSeq[pwListIdx].PowerInfo[0].PowerType == SensorId) && (PowerOnList.PowerSeq[pwListIdx].PowerInfo[0].Voltage != pinSetIdx))
						{
							PK_ERR("kdCISModulePowerOn %s is not %s\n",PowerOnList.PowerSeq[pwListIdx].SensorName, pinSetIdx ? "SUB_SENSOR":"MAIN_SENSOR");
							return ((int)SensorIdx << 1); //goto _kdCISModulePowerOn_exit_;
						}
					#endif
						if(hwpoweron(PowerOnList.PowerSeq[pwListIdx].PowerInfo[pwIdx],mode_name)==FALSE)
                            goto _kdCISModulePowerOn_exit_;
                    }
                    else
                    {
                        PK_DBG("kdCISModulePowerOn pwIdx=%d\n",pwIdx);
                        break;
                    }
                }
                break;
            }
            else if(PowerOnList.PowerSeq[pwListIdx].SensorName == NULL)
            {
                break;
            }
            else
			{
			}
        }

		// Temp solution: default power on/off sequence
        if(KAL_FALSE == sensorInPowerList)
		{
			//PK_DBG("Default power on sequence");
			// add ..
			PK_ERR("Pls. add power on sequence !!!");
			return ((int)SensorIdx << 1);
		}

	}
    else {//power OFF
        PK_ERR("kdCISModulePowerOff :currSensorName=%s,pinSetIdx=%d\n",currSensorName,pinSetIdx);

        for(pwListIdx=0; pwListIdx<16; pwListIdx++)
        {
            if(currSensorName && (PowerOnList.PowerSeq[pwListIdx].SensorName!=NULL) && (0 == strcmp(PowerOnList.PowerSeq[pwListIdx].SensorName,currSensorName)))
            {
                PK_DBG("kdCISModulePowerOff get in---sensorIdx:%d\n",SensorIdx);

                sensorInPowerList = KAL_TRUE;

                for(pwIdx=14; pwIdx>0; pwIdx--)
                {
                    if(PowerOnList.PowerSeq[pwListIdx].PowerInfo[pwIdx].PowerType != VDD_None)
                    {
					#ifdef OPIUM_CAM_SUPPORT
					    if((PowerOnList.PowerSeq[pwListIdx].PowerInfo[0].PowerType == SensorId) && (PowerOnList.PowerSeq[pwListIdx].PowerInfo[0].Voltage != pinSetIdx))
						{
							PK_ERR("kdCISModulePowerOff %s is not %s\n",PowerOnList.PowerSeq[pwListIdx].SensorName,pinSetIdx ? "SUB_SENSOR":"MAIN_SENSOR");
							return ((int)SensorIdx << 1); //goto _kdCISModulePowerOn_exit_;
						}
					#endif
                        if(hwpowerdown(PowerOnList.PowerSeq[pwListIdx].PowerInfo[pwIdx],mode_name)==FALSE)
                            goto _kdCISModulePowerOn_exit_;
                        if(pwIdx>0)
                        {
                            if(PowerOnList.PowerSeq[pwListIdx].PowerInfo[pwIdx-1].Delay > 0)
                                mdelay(PowerOnList.PowerSeq[pwListIdx].PowerInfo[pwIdx-1].Delay);
                        }
                    }
                    else
                    {
                        PK_DBG("kdCISModulePowerOff pwIdx=%d \n",pwIdx);
                    }
                }
            }
            else if(PowerOnList.PowerSeq[pwListIdx].SensorName == NULL)
            {
                break;
            }
            else
			{
			}
        }

		// Temp solution: default power on/off sequence
        if(KAL_FALSE == sensorInPowerList)
		{
			//PK_DBG("Default power on sequence");
			// add ..
			PK_ERR("Pls. add power off sequence !!!");
			return ((int)SensorIdx << 1);
		}
	}
    return 0;

_kdCISModulePowerOn_exit_:
    return -EIO;
}

EXPORT_SYMBOL(kdCISModulePowerOn);
